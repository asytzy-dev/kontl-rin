import os
import re
import json
import time
import asyncio
import logging
import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from pathlib import Path
from datetime import datetime, timedelta, timezone

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# ==========================
# Logging
# ==========================
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)

# ==========================
# Load Configuration
# ==========================
load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("❌ TELEGRAM_BOT_TOKEN tidak ditemukan di .env")

OWNER_IDS = {
    int(x.strip()) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()
}

# Multi sender via .env
GMAIL_ACCOUNTS_RAW = os.getenv("GMAIL_ACCOUNTS", "")
if GMAIL_ACCOUNTS_RAW:
    GMAIL_ACCOUNTS = [tuple(acc.strip().split(":", 1)) for acc in GMAIL_ACCOUNTS_RAW.split(",") if ":" in acc]
else:
    GMAIL_ACCOUNTS = []

EMAIL_SENDER = os.getenv("GMAIL_SENDER")
EMAIL_PASS = os.getenv("GMAIL_APP_PASSWORD")

APPEAL_SENDER_NAME = os.getenv("APPEAL_SENDER_NAME", "Repzsx")
APPEAL_RECIPIENTS = [e.strip() for e in os.getenv(
    "APPEAL_RECIPIENTS",
    "support@support.whatsapp.com,android@support.whatsapp.com"
).split(",") if e.strip()]

REPORT_WAIT_SECONDS = int(os.getenv("REPORT_WAIT_SECONDS", "45"))
MAX_REPORTS = int(os.getenv("MAX_REPORTS", "15"))
IMAP_POLL_INTERVAL = int(os.getenv("IMAP_POLL_INTERVAL", "5"))
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "465"))
IMAP_HOST = os.getenv("IMAP_HOST", "imap.gmail.com")

DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))
DATA_DIR.mkdir(exist_ok=True)

PREMIUM_DB_PATH = DATA_DIR / "premium.json"
REPORT_COUNT_PATH = DATA_DIR / "report_counts.json"
SENDERS_DB_PATH = DATA_DIR / "senders.json"

# ==========================
# Persistence helpers
# ==========================
def load_json_file(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_json_file(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

# ==========================
# Sender Manager
# ==========================
def get_senders() -> list:
    db = load_json_file(SENDERS_DB_PATH)
    senders = db.get("senders", [])
    if not senders and GMAIL_ACCOUNTS:
        senders = [{"email": e, "password": p} for e, p in GMAIL_ACCOUNTS]
        db["senders"] = senders
        save_json_file(SENDERS_DB_PATH, db)
    elif not senders and EMAIL_SENDER and EMAIL_PASS:
        senders = [{"email": EMAIL_SENDER, "password": EMAIL_PASS}]
        db["senders"] = senders
        save_json_file(SENDERS_DB_PATH, db)
    return senders

def add_sender(email_addr: str, password: str) -> None:
    db = load_json_file(SENDERS_DB_PATH)
    senders = db.get("senders", [])
    if any(s["email"] == email_addr for s in senders):
        return
    senders.append({"email": email_addr, "password": password})
    db["senders"] = senders
    save_json_file(SENDERS_DB_PATH, db)

def remove_sender(email_addr: str) -> bool:
    db = load_json_file(SENDERS_DB_PATH)
    senders = db.get("senders", [])
    new_senders = [s for s in senders if s["email"] != email_addr]
    if len(new_senders) == len(senders):
        return False
    db["senders"] = new_senders
    save_json_file(SENDERS_DB_PATH, db)
    return True

# ==========================
# Premium DB
# ==========================
def load_premium_db() -> dict:
    return load_json_file(PREMIUM_DB_PATH)

def save_premium_db(db: dict) -> None:
    save_json_file(PREMIUM_DB_PATH, db)

def add_premium(user_id: int, days=0, hours=0, minutes=0) -> datetime:
    db = load_premium_db()
    now = datetime.now(timezone.utc)
    prev_exp = db.get(str(user_id))
    start_time = datetime.fromisoformat(prev_exp) if prev_exp else now
    if start_time < now:
        start_time = now
    expiry = start_time + timedelta(days=days, hours=hours, minutes=minutes)
    db[str(user_id)] = expiry.isoformat()
    save_premium_db(db)
    return expiry

def get_premium_expiry(user_id: int):
    db = load_premium_db()
    exp = db.get(str(user_id))
    return datetime.fromisoformat(exp) if exp else None

def format_timedelta_until(expiry: datetime) -> str:
    now = datetime.now(timezone.utc)
    if expiry <= now:
        return "expired"
    diff = expiry - now
    d, s = divmod(diff.total_seconds(), 86400)
    h, s = divmod(s, 3600)
    m, _ = divmod(s, 60)
    return f"{int(d)}d {int(h)}h {int(m)}m"

def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS

# ==========================
# Utility
# ==========================
def normalize_number(number: str) -> str:
    number = number.strip()
    if number.startswith("0"):
        number = "62" + number[1:]
    elif number.startswith("+"):
        number = number[1:]
    return re.sub(r'\D', '', number)

def create_appeal_text(number: str) -> str:
    return f"""
Здравствуйте, служба поддержки WhatsApp!
Меня зовут {APPEAL_SENDER_NAME}, мой номер телефона +{number}. 
Я не могу войти в свой аккаунт WhatsApp, потому что постоянно получаю сообщение «Не могу войти», хотя я использую официальное приложение. 
Пожалуйста, проверьте и исправьте это как можно скорее, чтобы мой номер можно было повторно активировать. 
Спасибо
"""

# ==========================
# Email
# ==========================
def send_appeal_email_smtp(sender: str, password: str, recipient: str, subject: str, body: str) -> bool:
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = sender
        msg["To"] = recipient
        msg["Subject"] = subject
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT) as server:
            server.login(sender, password)
            server.sendmail(sender, [recipient], msg.as_string())
        logging.info(f"SMTP send OK from {sender} -> {recipient}")
        return True
    except Exception as e:
        logging.error(f"Email failed from {sender} to {recipient}: {e}")
        return False

def imap_search_recent_for_number(imap_host: str, email_user: str, email_pass: str, number: str,
                                  target_senders=None, timeout=REPORT_WAIT_SECONDS, poll_interval=IMAP_POLL_INTERVAL) -> bool:
    end_time = time.time() + timeout
    try:
        mail = imaplib.IMAP4_SSL(imap_host)
        mail.login(email_user, email_pass)
        mail.select("INBOX")
    except Exception as e:
        logging.error(f"IMAP login/select failed: {e}")
        return False

    target_senders = [s.lower() for s in (target_senders or [])]

    while time.time() < end_time:
        try:
            typ, data = mail.search(None, 'ALL')
            if typ != "OK":
                time.sleep(poll_interval)
                continue
            ids = data[0].split()[-30:]
            for msg_id in reversed(ids):
                typ, msg_data = mail.fetch(msg_id, "(RFC822)")
                if typ != "OK": continue
                raw = msg_data[0][1]
                parsed = email.message_from_bytes(raw)
                frm = parsed.get("From", "").lower()
                subject = parsed.get("Subject", "")
                body = ""
                if parsed.is_multipart():
                    for part in parsed.walk():
                        if part.get_content_type() == "text/plain" and part.get_payload(decode=True):
                            try:
                                body = part.get_payload(decode=True).decode(errors="ignore")
                                break
                            except: pass
                else:
                    try:
                        body = parsed.get_payload(decode=True).decode(errors="ignore")
                    except:
                        body = str(parsed.get_payload())
                if (not target_senders or any(ts in frm for ts in target_senders)) and (number in subject or number in body):
                    mail.logout()
                    return True
            time.sleep(poll_interval)
        except Exception as e:
            logging.error(f"IMAP poll error: {e}")
            time.sleep(poll_interval)
    try: mail.logout()
    except: pass
    return False

async def send_and_wait_for_report(recipient: str, number: str, subject: str, body: str,
                                   targets_for_detect=None, wait_seconds=REPORT_WAIT_SECONDS):
    loop = asyncio.get_running_loop()
    senders = get_senders()
    for s in senders:
        sent = await loop.run_in_executor(None, send_appeal_email_smtp, s["email"], s["password"], recipient, subject, body)
        if not sent:
            continue
        found = await loop.run_in_executor(
            None, imap_search_recent_for_number, IMAP_HOST, s["email"], s["password"],
            number, targets_for_detect or APPEAL_RECIPIENTS, wait_seconds, IMAP_POLL_INTERVAL
        )
        if found:
            return True, f"imap_found_via_{s['email']}"
    return False, "all_senders_failed"

# ==========================
# Report-count
# ==========================
def get_report_counts() -> dict:
    return load_json_file(REPORT_COUNT_PATH)

def increment_report_count(number: str) -> int:
    db = get_report_counts()
    cnt = db.get(number, 0) + 1
    db[number] = cnt
    save_json_file(REPORT_COUNT_PATH, db)
    return cnt

# ==========================
# Commands
# ==========================
async def jebol_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        return await update.message.reply_text("❌ Usage: /jebol <number>")

    number = normalize_number(context.args[0])
    current_count = get_report_counts().get(number, 0)
    if current_count >= MAX_REPORTS:
        return await update.message.reply_text(f"❌ Nomor +{number} sudah limit ({current_count}/{MAX_REPORTS}).")

    await update.message.reply_text(f"🚀 Mulai jebol untuk +{number}")

    subject = f"Жалоба на номер: +{number}"
    body = create_appeal_text(number)

    for idx, recipient in enumerate(APPEAL_RECIPIENTS):
        await update.message.reply_text(f"➡️ Mengirim ke {recipient} ({idx+1}/{len(APPEAL_RECIPIENTS)})...")
        found, status = await send_and_wait_for_report(recipient, number, subject, body, APPEAL_RECIPIENTS, REPORT_WAIT_SECONDS)
        cnt = increment_report_count(number)
        if found:
            return await update.message.reply_text(f"✅ Laporan muncul untuk +{number} via {recipient}. Total: {cnt}/{MAX_REPORTS}")
        else:
            if cnt >= MAX_REPORTS:
                return await update.message.reply_text(f"❌ Batas percobaan tercapai untuk +{number} ({cnt}/{MAX_REPORTS}).")
            await update.message.reply_text(f"⚠️ Tidak ada laporan dari {recipient}. Percobaan {cnt}/{MAX_REPORTS}, coba lanjut...")

    await update.message.reply_text(f"done bypass  untuk +{number}✅ abaikam pesan di atas")

# Sender management
async def addsender_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Only owner can add sender.")
    if not context.args or ":" not in context.args[0]:
        return await update.message.reply_text("Usage: /addsender email:app_pass")
    email_acc, password = context.args[0].split(":", 1)
    add_sender(email_acc, password)
    await update.message.reply_text(f"✅ Sender {email_acc} ditambahkan.")

async def remsender_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Only owner can remove sender.")
    if not context.args:
        return await update.message.reply_text("Usage: /remsender email")
    email_acc = context.args[0]
    if remove_sender(email_acc):
        await update.message.reply_text(f"❌ Sender {email_acc} dihapus.")
    else:
        await update.message.reply_text(f"⚠️ Sender {email_acc} tidak ditemukan.")

async def listsender_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    senders = get_senders()
    if not senders:
        return await update.message.reply_text("⚠️ Belum ada sender.")
    txt = "📧 Sender aktif:\n" + "\n".join(f"- {s['email']}" for s in senders)
    await update.message.reply_text(txt)

# Menu basic
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome!\nUse /jebol <number> untuk appeal.\nOwner bisa /addsender /remsender /listsenders")

# ==========================
# Main
# ==========================
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("jebol", jebol_command))
    app.add_handler(CommandHandler("addsender", addsender_command))
    app.add_handler(CommandHandler("remsender", remsender_command))
    app.add_handler(CommandHandler("listsenders", listsender_command))
    logging.info("🚀 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
