import os
import json
import logging
import smtplib
from email.mime.text import MIMEText
from pathlib import Path
from datetime import datetime, timedelta, timezone

from dotenv import load_dotenv
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# ==========================
# Logging
# ==========================
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)

# ==========================
# Load Configuration
# ==========================
load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("❌ TELEGRAM_BOT_TOKEN tidak ditemukan di .env")

OWNER_IDS = {
    int(x.strip()) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()
}

EMAIL_SENDER = os.getenv("GMAIL_SENDER")
EMAIL_PASS = os.getenv("GMAIL_APP_PASSWORD")

PAYMENT_DANA = os.getenv("PAYMENT_DANA", "08xxxxxxx a/n YourName")
PAYMENT_OVO = os.getenv("PAYMENT_OVO", "08xxxxxxx a/n YourName")
PAYMENT_SHOPEE = os.getenv("PAYMENT_SHOPEE", "08xxxxxxx a/n YourName")
PAYMENT_QRIS = os.getenv("PAYMENT_QRIS", "QRIS link not provided")

PREMIUM_DB_PATH = Path("premium.json")

# ==========================
# Premium Database
# ==========================
def load_premium_db() -> dict:
    if not PREMIUM_DB_PATH.exists():
        return {}
    try:
        with PREMIUM_DB_PATH.open("r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_premium_db(db: dict) -> None:
    with PREMIUM_DB_PATH.open("w", encoding="utf-8") as f:
        json.dump(db, f, indent=2)

def add_premium(user_id: int, days=0, hours=0, minutes=0) -> datetime:
    db = load_premium_db()
    now = datetime.now(timezone.utc)
    prev_exp = db.get(str(user_id))
    start_time = datetime.fromisoformat(prev_exp) if prev_exp else now
    if start_time < now:
        start_time = now
    expiry = start_time + timedelta(days=days, hours=hours, minutes=minutes)
    db[str(user_id)] = expiry.isoformat()
    save_premium_db(db)
    return expiry

def remove_premium(user_id: int) -> None:
    db = load_premium_db()
    if str(user_id) in db:
        del db[str(user_id)]
        save_premium_db(db)

def get_premium_expiry(user_id: int):
    db = load_premium_db()
    exp = db.get(str(user_id))
    return datetime.fromisoformat(exp) if exp else None

def format_timedelta_until(expiry: datetime) -> str:
    now = datetime.now(timezone.utc)
    if expiry <= now:
        return "expired"
    diff = expiry - now
    d, s = divmod(diff.total_seconds(), 86400)
    h, s = divmod(s, 3600)
    m, _ = divmod(s, 60)
    return f"{int(d)}d {int(h)}h {int(m)}m"

def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS

# ==========================
# Utility untuk Jebol
# ==========================
def normalize_number(number: str) -> str:
    number = number.strip()
    if number.startswith("0"):
        number = "62" + number[1:]
    elif number.startswith("+"):
        number = number[1:]
    return number

def create_appeal_text(number: str, sender_name: str = "Repzsx") -> str:
    return f"""
Здравствуйте, служба поддержки WhatsApp!
Меня зовут {sender_name}, мой номер телефона +{number}. 
Я не могу войти в свой аккаунт WhatsApp, потому что постоянно получаю сообщение «Не могу войти», хотя я использую официальное приложение. 
Пожалуйста, проверьте и исправьте это как можно скорее, чтобы мой номер можно было повторно активировать. 
Спасибо
"""

def send_appeal_email(recipient: str, subject: str, body: str) -> bool:
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = EMAIL_SENDER
        msg["To"] = recipient
        msg["Subject"] = subject

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(EMAIL_SENDER, EMAIL_PASS)
            server.sendmail(EMAIL_SENDER, [recipient], msg.as_string())
        return True
    except Exception as e:
        logging.error(f"Email failed: {e}")
        return False

# ==========================
# /jebol Command
# ==========================
TARGETS = {
    "support": "support@support.whatsapp.com",
    "android": "android@support.whatsapp.com",
}

async def jebol_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        return await update.message.reply_text("❌ Usage: /jebol <number>")

    number = normalize_number(context.args[0])

    keyboard = [
        [InlineKeyboardButton("📧 support@support.whatsapp.com", callback_data=f"jebol_support_{number}")],
        [InlineKeyboardButton("📧 android@support.whatsapp.com", callback_data=f"jebol_android_{number}")],
    ]
    await update.message.reply_text(
        f"Menemukan 1 nomor.\nSilakan pilih tujuan pengiriman:\n{number}",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split("_")
    if len(data) < 3:
        return await query.edit_message_text("⚠️ Invalid action.")

    _, target, number = data
    email = TARGETS.get(target)
    if not email:
        return await query.edit_message_text("⚠️ Target not found.")

    subject = f"Жалоба на номер: +{number}"
    body = create_appeal_text(number)

    success, failed = [], []

    if send_appeal_email(email, subject, body):
        success.append(number)
    else:
        failed.append(number)

    result_text = f"Mulai mengirim ke {email} untuk 1 nomor...\n\n"
    if success:
        result_text += f"[1] ✅ Berhasil: +{success[0]}\n"
    if failed:
        result_text += f"[1] ❌ Gagal: +{failed[0]}\n"
    result_text += f"\nSelesai.\nBerhasil: {len(success)}\nGagal: {len(failed)}"

    await query.edit_message_text(result_text)

# ==========================
# Commands
# ==========================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome!\nUse /menu to see available commands.")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 Help Menu:\n"
        "/start - Start bot\n"
        "/menu - Show menu\n"
        "/buy - Buy premium\n"
        "/mypremium - Check premium status\n"
        "/admin - Admin menu\n"
        "/jebol <number> - Kirim laporan nomor\n"
        "/addpremium <id> <days> <hours> <minutes>\n"
        "/removepremium <id>\n"
        "/checkpremium <id>"
    )
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="menu_back")]]
    if update.message:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    elif update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Buy Premium", callback_data="menu_buy")],
        [InlineKeyboardButton("Check Premium", callback_data="menu_check")],
        [InlineKeyboardButton("Help", callback_data="menu_help")],
    ]
    text = "📌 Main Menu:"
    if update.message:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    elif update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Only admins can access this menu.")
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="menu_back")]]
    await update.message.reply_text(
        "🔧 Admin Menu:\n"
        "/addpremium <id> <days> <hours> <minutes>\n"
        "/removepremium <id>\n"
        "/checkpremium <id>",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ==========================
# Premium & Payment Commands
# ==========================
async def mypremium_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    exp = get_premium_expiry(uid)
    if not exp:
        text = "❌ You don't have premium."
    else:
        status = "Active ✅" if exp > datetime.now(timezone.utc) else "Expired ❌"
        text = (
            f"👤 User: {update.effective_user.first_name}\n"
            f"ID: {uid}\n"
            f"Status: {status}\n"
            f"Expires: {exp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            f"Remaining: {format_timedelta_until(exp)}"
        )
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="menu_back")]]
    if update.message:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    elif update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def addpremium_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Not admin.")
    if len(context.args) < 4:
        return await update.message.reply_text("Usage: /addpremium <user_id> <days> <hours> <minutes>")
    uid = int(context.args[0])
    d, h, m = map(int, context.args[1:4])
    exp = add_premium(uid, d, h, m)
    remain = format_timedelta_until(exp)
    await update.message.reply_text(f"✅ Premium {uid} active until {exp} ({remain})")

async def removepremium_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Not admin.")
    uid = int(context.args[0])
    remove_premium(uid)
    await update.message.reply_text(f"❌ Premium removed for {uid}")

async def checkpremium_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return await update.message.reply_text("❌ Not admin.")
    uid = int(context.args[0])
    exp = get_premium_expiry(uid)
    if not exp:
        return await update.message.reply_text("❌ User not premium.")
    await update.message.reply_text(f"User {uid}\nExpires: {exp}\nRemaining: {format_timedelta_until(exp)}")

async def buy_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("DANA", callback_data="pay_dana")],
        [InlineKeyboardButton("OVO", callback_data="pay_ovo")],
        [InlineKeyboardButton("ShopeePay", callback_data="pay_shopee")],
        [InlineKeyboardButton("QRIS", callback_data="pay_qris")],
        [InlineKeyboardButton("⬅️ Back", callback_data="menu_back")],
    ]
    text = "💳 Choose payment method:"
    if update.message:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    elif update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def payment_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    method = query.data

    if method == "pay_dana":
        text = f"Transfer via DANA:\n{PAYMENT_DANA}"
    elif method == "pay_ovo":
        text = f"Transfer via OVO:\n{PAYMENT_OVO}"
    elif method == "pay_shopee":
        text = f"Transfer via ShopeePay:\n{PAYMENT_SHOPEE}"
    elif method == "pay_qris":
        text = f"Scan this QRIS link:\n{PAYMENT_QRIS}"
    else:
        text = "⚠️ Invalid payment method."

    text += "\n\nAfter payment, send screenshot here."
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="menu_back")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

# ==========================
# Proof of Payment
# ==========================
async def proof_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        return
    user = update.effective_user
    caption = f"📩 Proof of payment from {user.first_name} (ID: {user.id})"
    for oid in OWNER_IDS:
        try:
            await context.bot.send_photo(
                chat_id=oid,
                photo=update.message.photo[-1].file_id,
                caption=caption
            )
        except Exception as e:
            logging.error(f"Failed send proof: {e}")
    await update.message.reply_text("✅ Proof received, waiting for admin confirmation.")

# ==========================
# Menu Callback
# ==========================
async def menu_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    action = query.data

    if action == "menu_buy":
        return await buy_command(update, context)
    elif action == "menu_check":
        return await mypremium_command(update, context)
    elif action == "menu_help":
        return await help_command(update, context)
    elif action == "menu_back":
        return await menu_command(update, context)
    else:
        await query.edit_message_text("⚠️ Unknown menu option.")

# ==========================
# Main
# ==========================
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Menu callbacks
    app.add_handler(CallbackQueryHandler(menu_button, pattern="^menu_"))
    app.add_handler(CallbackQueryHandler(payment_button, pattern="^pay_"))
    app.add_handler(CallbackQueryHandler(button_callback, pattern="^jebol_"))

    # Commands
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("menu", menu_command))
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(CommandHandler("jebol", jebol_command))

    app.add_handler(CommandHandler("mypremium", mypremium_command))
    app.add_handler(CommandHandler("addpremium", addpremium_command))
    app.add_handler(CommandHandler("removepremium", removepremium_command))
    app.add_handler(CommandHandler("checkpremium", checkpremium_command))

    app.add_handler(CommandHandler("buy", buy_command))
    app.add_handler(MessageHandler(filters.PHOTO, proof_handler))

    logging.info("🚀 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
